package com.example.browserstack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BrowserStackApplication {

    public static void main(String[] args) {
        SpringApplication.run(BrowserStackApplication.class, args);
    }

}
